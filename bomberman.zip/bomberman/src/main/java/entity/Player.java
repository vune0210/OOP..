package entity;

import com.sun.xml.internal.ws.api.ResourceLoader;
import main.GamePanel;
import main.KeyHendler;
import tile.Brick;
import tile.Tile;
import tile.TileManager;
import tile.Wall;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;

public class Player extends Entity {
    GamePanel gp;
    KeyHendler keyH;
    BufferedImage up, up1, up2, down, down1, down2;
    BufferedImage left, left1, left2, right, right1, right2;

    public Player(GamePanel gamePanel, KeyHendler keyHendler) {
        this.gp = gamePanel;
        this.keyH = keyHendler;
        setDefaultValues();
        getPlayerImage();
    }

    public void setDefaultValues() {
        x = gp.tileSize + 1;
        y = gp.tileSize + 1;
        healthPoint = 1;
        speed = 2;
        direction = "down";
    }

    public void getPlayerImage() {
        try {
            down = ImageIO.read(new File("src/main/resources/Player/player_down.png"));
            down1 = ImageIO.read(new File("src/main/resources/Player/player_down_1.png"));
            down2 = ImageIO.read(new File("src/main/resources/Player/player_down_2.png"));
            up = ImageIO.read(new File("src/main/resources/Player/player_up.png"));
            up1 = ImageIO.read(new File("src/main/resources/Player/player_up_1.png"));
            up2 = ImageIO.read(new File("src/main/resources/Player/player_up_2.png"));
            left = ImageIO.read(new File("src/main/resources/Player/player_left.png"));
            left1 = ImageIO.read(new File("src/main/resources/Player/player_left_1.png"));
            left2 = ImageIO.read(new File("src/main/resources/Player/player_left_2.png"));
            right = ImageIO.read(new File("src/main/resources/Player/player_right.png"));
            right1 = ImageIO.read(new File("src/main/resources/Player/player_right_1.png"));
            right2 = ImageIO.read(new File("src/main/resources/Player/player_right_2.png"));
        } catch (IOException exception) {
            exception.printStackTrace();
        }
    }

    public void update(TileManager tileM) {
        if (keyH.upPressed || keyH.downPressed || keyH.leftPressed || keyH.rightPressed) {

            if (keyH.upPressed) {
                direction = "up";
                y -= speed;
                boolean check = false;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) y += speed;
                check = false;
                for (Brick brick : tileM.brickList) {
                    if (checkCollisionBrickWall(brick)) {
                        check = true;
                        break;
                    }
                }
                if (check) y += speed;
            }
            if (keyH.downPressed) {
                direction = "down";
                y += speed;
                boolean check = false;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) y -= speed;
                check = false;
                for (Brick brick : tileM.brickList) {
                    if (checkCollisionBrickWall(brick)) {
                        check = true;
                        break;
                    }
                }
                if (check) y -= speed;
            }
            if (keyH.leftPressed) {
                direction = "left";
                x -= speed;
                boolean check = false;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) x += speed;
                check = false;
                for (Brick brick : tileM.brickList) {
                    if (checkCollisionBrickWall(brick)) {
                        check = true;
                        break;
                    }
                }
                if (check) x += speed;
            }
            if (keyH.rightPressed) {
                direction = "right";
                x += speed;
                boolean check = false;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) x -= speed;
                check = false;
                for (Brick brick : tileM.brickList) {
                    if (checkCollisionBrickWall(brick)) {
                        check = true;
                        break;
                    }
                }
                if (check) x -= speed;
            }

            spriteCounter++;
            if (spriteCounter > 10) {
                if (spriteNum == 1) {
                    spriteNum = 2;
                } else if (spriteNum == 2) {
                    spriteNum = 3;
                } else if (spriteNum == 3) {
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }
        }

    }

    @Override
    public boolean checkCollisionBrickWall(Tile tile) {
        Rectangle entityBound = new Rectangle(x + 10,y + 14,32,32);
        Rectangle tileBound = new Rectangle(tile.x, tile.y, gp.tileSize, gp.tileSize);
        return entityBound.intersects(tileBound);
    }

    @Override
    public boolean checkCollision(Entity entity) {
        Rectangle entityBound = new Rectangle(x + 10,y + 14,32,32);
        Rectangle tileBound = new Rectangle(entity.x, entity.y, gp.tileSize, gp.tileSize);
        return entityBound.intersects(tileBound);
    }

    public void draw(Graphics2D g2) {
//        g2.setColor(Color.white);
//        g2.fillRect(x, y, gp.tileSize, gp.tileSize);

        BufferedImage image = null;

        switch (direction) {
            case "up":
                if (spriteNum == 1) {
                    image = up;
                }
                if (spriteNum == 2) {
                    image = up1;
                }
                if (spriteNum == 3) {
                    image = up2;
                }
                if (!keyH.upPressed) image = up;
                break;
            case "down":
                if (spriteNum == 1) {
                    image = down;
                }
                if (spriteNum == 2) {
                    image = down1;
                }
                if (spriteNum == 3) {
                    image = down2;
                }
                if (!keyH.downPressed) image = down;
                break;
            case "left":
                if (spriteNum == 1) {
                    image = left;
                }
                if (spriteNum == 2) {
                    image = left1;
                }
                if (spriteNum == 3) {
                    image = left2;
                }
                if (!keyH.leftPressed) image = left;
                break;
            case "right":
                if (spriteNum == 1) {
                    image = right;
                }
                if (spriteNum == 2) {
                    image = right1;
                }
                if (spriteNum == 3) {
                    image = right2;
                }
                if (!keyH.rightPressed) image = right;
                break;
        }

        g2.drawImage(image, x, y, gp.tileSize, gp.tileSize - 2, null);
    }
}
