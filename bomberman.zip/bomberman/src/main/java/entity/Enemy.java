//package entity;
//
//import main.GamePanel;
//import tile.Brick;
//import tile.Tile;
//import tile.TileManager;
//import tile.Wall;
//
//import javax.imageio.ImageIO;
//import java.awt.*;
//import java.awt.image.BufferedImage;
//import java.io.File;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Random;
//
//public class Enemy extends Entity{
//
//    public List<Entity> mob1 = new ArrayList<>();
//
//    public Enemy(GamePanel gamepanel) {
//        this.gp = gamepanel;
//        getMob1Image();
//        setMob1Default();
//    }
//
//
//    public void setMob1Default() {
//        Entity m1 = new Entity();
//        m1.x = 4 * gp.tileSize;
//        m1.y = 4 * gp.tileSize;
//        m1.direction = "down";
//        m1.randomMoves = 0;
//        speed = 2;
//        mob1.add(m1);
//    }
//    public void update(TileManager tileM) {
//        for (Entity e : mob1) {
//            if (e.direction.equals("down")) {
//                e.y += speed;
//                boolean check = false;
//                for (Wall wall : tileM.wallList) {
//                    if (e.checkCollision(wall)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.y -= speed;
//                check = false;
//                for (Brick brick : tileM.brickList) {
//                    if (e.checkCollision(brick)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.y -= speed;
//            }
//            else if (e.direction.equals("up")) {
//                e.y -= speed;
//                boolean check = false;
//                for (Wall wall : tileM.wallList) {
//                    if (e.checkCollision(wall)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.y += speed;
//                check = false;
//                for (Brick brick : tileM.brickList) {
//                    if (e.checkCollision(brick)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.y += speed;
//            }
//            else if (e.direction.equals("left")) {
//                e.x -= speed;
//                boolean check = false;
//                for (Wall wall : tileM.wallList) {
//                    if (e.checkCollision(wall)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.x += speed;
//                check = false;
//                for (Brick brick : tileM.brickList) {
//                    if (e.checkCollision(brick)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.x += speed;
//            }
//            else if (e.direction.equals("right")) {
//                e.x += speed;
//                boolean check = false;
//                for (Wall wall : tileM.wallList) {
//                    if (e.checkCollision(wall)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.x -= speed;
//                check = false;
//                for (Brick brick : tileM.brickList) {
//                    if (e.checkCollision(brick)) {
//                        check = true;
//                        break;
//                    }
//                }
//                if (check) e.x -= speed;
//            }
//
//            for (Wall wall : tileM.wallList)
//                if (e.checkCollisionBrickWall(wall)) {
//                    Random rand = new Random();
//                    e.randomMoves = rand.nextInt(4);
//                    System.out.println(e.randomMoves);
//                    if (e.randomMoves == 0) {
//                        e.direction = "down";
//                    }
//                    if (e.randomMoves == 1) {
//                        e.direction ="up";
//                    }
//                    if (e.randomMoves == 2) {
//                        e.direction = "left";
//                    }
//                    if (e.randomMoves == 3) {
//                        e.direction = "right";
//                    }
//                }
//            for (Brick brick : tileM.brickList)
//                if (e.checkCollisionBrickWall(brick)) {
//                Random rand = new Random();
//                e.randomMoves = rand.nextInt(4);
//                System.out.println(e.randomMoves);
//                if (e.randomMoves == 0) {
//                    e.direction = "down";
//                }
//                if (e.randomMoves == 1) {
//                    e.direction ="up";
//                }
//                if (e.randomMoves == 2) {
//                    e.direction = "left";
//                }
//                if (e.randomMoves == 3) {
//                    e.direction = "right";
//                }
//            }
//        }
//    }
//
//
//    public void draw(Graphics2D g2) {
//        BufferedImage image = left1;
//        for (Entity e : mob1) {
//            g2.drawImage(image,e.x,e.y,gp.tileSize,gp.tileSize,null);
//        }
//    }
//
//    @Override
//    public boolean checkCollision(Tile tile) {
//        return false;
//    }
//}
