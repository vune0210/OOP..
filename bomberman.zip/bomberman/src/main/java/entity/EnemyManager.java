package entity;

import main.GamePanel;
import tile.TileManager;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class EnemyManager {
    GamePanel gamePanel;
    public List<Balloon> balloonList = new ArrayList<>();
    public List<Kondoria> kondoriaList = new ArrayList<>();
    public EnemyManager(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
        balloonList.add(new Balloon(7 * gamePanel.tileSize, 2 * gamePanel.tileSize, gamePanel));
        balloonList.add(new Balloon(3 * gamePanel.tileSize, 10 * gamePanel.tileSize, gamePanel));
        //balloonList.add(new Balloon(2 * gamePanel.tileSize, 1 * gamePanel.tileSize, gamePanel));
        kondoriaList.add(new Kondoria(10 * gamePanel.tileSize, 2 * gamePanel.tileSize, gamePanel));
        kondoriaList.add(new Kondoria(14 * gamePanel.tileSize, 6 * gamePanel.tileSize, gamePanel));
    }

    public void drawEnemy(Graphics2D graphics2D) {
        for (Balloon balloon : balloonList) {
            balloon.draw(graphics2D);
        }
        for (Kondoria kondoria : kondoriaList) {
            kondoria.draw(graphics2D);
        }
    }

    public void updateEnemy(TileManager tileM) {
        for (Balloon balloon : balloonList) {
            balloon.update(tileM);
        }
        for (Kondoria kondoria : kondoriaList) {
            kondoria.update(tileM);
        }
    }
}
