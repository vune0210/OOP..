package entity;

import main.GamePanel;
import tile.Brick;
import tile.Tile;
import tile.TileManager;
import tile.Wall;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Kondoria extends Entity{
    public BufferedImage dead, left1, left2, left3, right1, right2, right3, dead1, dead2, dead3;

    public Kondoria(int x, int y, GamePanel gamePanel) {
        this.x = x;
        this.y = y;
        this.gp = gamePanel;
        this.setDefaultValues();
        this.getBalloonImage();
    }

    public void setDefaultValues() {
        speed = 1;
        healthPoint = 1;
        direction = "down";
    }

    public void getBalloonImage() {
        try {
            dead = ImageIO.read(new File("src/main/resources/Enemy/kondoria_dead.png"));
            left1 =ImageIO.read(new File("src/main/resources/Enemy/kondoria_left1.png"));
            left2 =ImageIO.read(new File("src/main/resources/Enemy/kondoria_left2.png"));
            left3 =ImageIO.read(new File("src/main/resources/Enemy/kondoria_left3.png"));
            right1 =ImageIO.read(new File("src/main/resources/Enemy/kondoria_right1.png"));
            right2 =ImageIO.read(new File("src/main/resources/Enemy/kondoria_right2.png"));
            right3 =ImageIO.read(new File("src/main/resources/Enemy/kondoria_right3.png"));
            dead1 =ImageIO.read(new File("src/main/resources/Enemy/mob_dead1.png"));
            dead2 =ImageIO.read(new File("src/main/resources/Enemy/mob_dead2.png"));
            dead3 =ImageIO.read(new File("src/main/resources/Enemy/mob_dead3.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update(TileManager tileM) {
        List<String> listDirection = new ArrayList<>();
        boolean check = false;
        tileX = (int) x / gp.tileSize;
        tileY = (int) y / gp.tileSize;
        switch (direction) {
            case "down":
                y += speed;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) {
                    y -= speed;
                    tileX = (int) x / gp.tileSize;
                    tileY = (int) y / gp.tileSize;
                    listDirection.add("up");
                    if (tileM.mapTile[tileY][tileX + 1] != 1) {
                        listDirection.add("right");
                    }
                    if (tileM.mapTile[tileY][tileX - 1] != 1) {
                        listDirection.add("left");
                    }
                    if (listDirection.size() == 1) {
                        direction = listDirection.get(0);
                    } else {
                        // (listDirection.size() - 1) =  max; 0 = min
                        int random_int = (int)(Math.random() * ((listDirection.size() - 1) - 0 + 1) + 0);
                        direction = listDirection.get(random_int);
                    }
                    listDirection.removeAll(listDirection);
                }
                break;
            case "up":
                y -= speed;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) {
                    y += speed;
                    tileX = (int) x / gp.tileSize;
                    tileY = (int) y / gp.tileSize;
                    listDirection.add("down");
                    if (tileM.mapTile[tileY][tileX + 1] != 1) {
                        listDirection.add("right");
                    }
                    if (tileM.mapTile[tileY][tileX - 1] != 1) {
                        listDirection.add("left");
                    }
                    if (listDirection.size() == 1) {
                        direction = listDirection.get(0);
                    } else {
                        // (listDirection.size() - 1) =  max; 0 = min
                        int random_int = (int)(Math.random() * ((listDirection.size() - 1) - 0 + 1) + 0);
                        direction = listDirection.get(random_int);
                    }
                    listDirection.removeAll(listDirection);
                }
                break;
            case "left":
                x -= speed;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) {
                    x += speed;
                    tileX = (int) x / gp.tileSize;
                    tileY = (int) y / gp.tileSize;
                    listDirection.add("right");
                    if (tileM.mapTile[tileY + 1][tileX] != 1) {
                        listDirection.add("down");
                    }
                    if (tileM.mapTile[tileY - 1][tileX] != 1) {
                        listDirection.add("up");
                    }
                    if (listDirection.size() == 1) {
                        direction = listDirection.get(0);
                    } else {
                        // (listDirection.size() - 1) =  max; 0 = min
                        int random_int = (int)(Math.random() * ((listDirection.size() - 1) - 0 + 1) + 0);
                        direction = listDirection.get(random_int);
                    }
                    listDirection.removeAll(listDirection);
                }
                break;
            case "right":
                x += speed;
                for (Wall wall : tileM.wallList) {
                    if (checkCollisionBrickWall(wall)) {
                        check = true;
                        break;
                    }
                }
                if (check) {
                    x -= speed;
                    tileX = (int) x / gp.tileSize;
                    tileY = (int) y / gp.tileSize;
                    listDirection.add("left");
                    if (tileM.mapTile[tileY + 1][tileX] != 1) {
                        listDirection.add("down");
                    }
                    if (tileM.mapTile[tileY - 1][tileX] != 1) {
                        listDirection.add("up");
                    }
                    if (listDirection.size() == 1) {
                        direction = listDirection.get(0);
                    } else {
                        // (listDirection.size() - 1) =  max; 0 = min
                        int random_int = (int)(Math.random() * ((listDirection.size() - 1) - 0 + 1) + 0);
                        direction = listDirection.get(random_int);
                    }
                    listDirection.removeAll(listDirection);
                }
                break;
            default:
                break;
        }

        spriteCounter++;
        if (spriteCounter > 10) {
            if (spriteNum == 1) {
                spriteNum = 2;
            } else if (spriteNum == 2) {
                spriteNum = 3;
            } else if (spriteNum == 3) {
                spriteNum = 1;
            }
            spriteCounter = 0;
        }
    }

    public void draw(Graphics2D g2) {
        BufferedImage image = null;
        switch (direction) {
            case "up":
            case "left":
                if (spriteNum == 1) {
                    image = left1;
                }
                if (spriteNum == 2) {
                    image = left2;
                }
                if (spriteNum == 3) {
                    image = left3;
                }
                break;
            case "down":
            case "right":
                if (spriteNum == 1) {
                    image = right1;
                }
                if (spriteNum == 2) {
                    image = right2;
                }
                if (spriteNum == 3) {
                    image = right3;
                }
                break;
        }
        g2.drawImage(image, x, y, gp.tileSize, gp.tileSize, null);
        if (right1 == null) System.out.println("1");
    }



    @Override
    public boolean checkCollisionBrickWall(Tile tile) {
        Rectangle entityBound = new Rectangle(x, y,gp.tileSize, gp.tileSize);
        Rectangle tileBound = new Rectangle(tile.x, tile.y, gp.tileSize, gp.tileSize);
        return entityBound.intersects(tileBound);
    }

    @Override
    public boolean checkCollision(Entity entity) {
        Rectangle entityBound = new Rectangle(x + 2, y + 2,gp.tileSize - 2, gp.tileSize - 2);
        Rectangle tileBound = new Rectangle(entity.x, entity.y, gp.tileSize, gp.tileSize);
        return entityBound.intersects(tileBound);
    }
}
