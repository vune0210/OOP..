package entity;

import main.GamePanel;
import main.KeyHendler;
import tile.Flame;
import tile.FlameTile;
import tile.Tile;
import tile.TileManager;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Bomb extends Entity {
    public BufferedImage b,b1,b2;
    Player player;
    public int range;
    public double newTimeToBomb;
    public double startCounter;
    public double remainingTime;
    boolean exploded = false;
    Flame[] flame = new Flame[4];
    public String status;

    public Bomb(GamePanel gamepanel, Player p) {
        this.gp = gamepanel;
        this.player = p;
        range = 1;
        getImage();
        newTimeToBomb = 0;
        status = "preparing_explosive";
    }

    public void getImage() {
        try {
            b = ImageIO.read(new File("src/main/resources/Bomb/bomb.png"));
            b1 = ImageIO.read(new File("src/main/resources/Bomb/bomb_1.png"));
            b2 = ImageIO.read(new File("src/main/resources/Bomb/bomb_2.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void update(KeyHendler key, TileManager tileM) {
        if (key.spacePressed) {
            newTimeToBomb++;
            remainingTime = System.nanoTime();
            if (newTimeToBomb == 1) {
                startCounter = System.nanoTime();
                tileX =  ((player.x + gp.tileSize / 2) / gp.tileSize) * gp.tileSize;
                tileY =  ((player.y + gp.tileSize / 2) / gp.tileSize) * gp.tileSize;
                for (int i = 0; i < 4; i++) {
                    flame[i] = new Flame(tileX, tileY, i, range, gp);
                }
            }
            else if ((remainingTime - startCounter)/ 1000000 <= 3000) {
                updateAnimation();

            } else if ((remainingTime - startCounter)/ 1000000 > 3000) {
                status = "exploding";
                for (int i = 0; i < 4; i++) {
                    flame[i].updateFlame(tileM, this);
                }
                if (flame[0].spriteNum >= 4) {
                    newTimeToBomb = 0;
                    key.spacePressed = false;
                    status = "exploded";
                }
            }
        }
    }
    public void updateAnimation() {
        spriteCounter++;
        if (spriteCounter > 10) {
            if (spriteNum == 1) {
                spriteNum = 2;
            }
            else if (spriteNum == 2) {
                spriteNum = 3;
            }
            else if (spriteNum == 3) {
                spriteNum = 1;
            }
            spriteCounter = 0;
        }
    }
    public void draw(Graphics2D g2, KeyHendler key) {
        BufferedImage image;
        if (key.spacePressed) {
            switch(spriteNum){
                case 1:
                    image = b;
                    break;
                case 2:
                    image = b1;
                    break;
                case 3:
                    image = b2;
                    break;
                default:
                    image = null;
            }
            g2.drawImage(image, tileX, tileY, gp.tileSize,gp.tileSize, null);
            if ((remainingTime - startCounter)/ 1000000 > 3000) {
                for (int i = 0;i < 4; i++)
                    flame[i].draw(g2);
            }

        }

    }


    @Override
    public boolean checkCollisionBrickWall(Tile tile) {
        return false;
    }

    @Override
    public boolean checkCollision(Entity entity) {
        return false;
    }

}
