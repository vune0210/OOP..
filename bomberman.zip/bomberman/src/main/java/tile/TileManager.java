package tile;

import entity.Bomb;
import main.GamePanel;

import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

public class TileManager {
    GamePanel gamePanel;
    public List<Grass> grassList = new ArrayList<Grass>();
    public List<Wall> wallList = new ArrayList<Wall>();
    public List<Brick> brickList = new ArrayList<Brick>();
    public int mapTile[][];

    Bomb bomb;


    public TileManager(GamePanel gamePanel, Bomb bomb) {
        this.gamePanel = gamePanel;
        this.bomb = bomb;
        mapTile = new int[gamePanel.maxScreenRow][gamePanel.maxScreenCol];

        loadMap();
    }

    public void loadMap() {
        try {
            InputStream inputStream = Files.newInputStream(new File("src/main/resources/Map/map01.txt").toPath());
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            for (int i = 0; i < gamePanel.maxScreenRow; i++) {
                String line = bufferedReader.readLine();
                String[] parts = line.split(" ");
                for (int j = 0; j < gamePanel.maxScreenCol; j++) {
                    mapTile[i][j] = Integer.parseInt(parts[j]);
                    grassList.add(new Grass(gamePanel.tileSize * j, gamePanel.tileSize * i));

                    switch (mapTile[i][j]) {
                        case 1:
                            wallList.add(new Wall(gamePanel.tileSize * j, gamePanel.tileSize * i));
                            break;
                        case 2:
                            brickList.add(new Brick(gamePanel.tileSize * j, gamePanel.tileSize * i, j, i));
                            break;
                        default:
                            break;
                    }
                }
            }
        } catch (Exception exception) {
            exception.getStackTrace();
        }
    }

    public void update() {
        for (Brick brick : brickList) {
            brick.update(gamePanel, this.brickList, this.bomb, mapTile);
        }
        System.out.println(brickList.size());
    }

    public void draw(Graphics2D graphics2D) {



        for (Wall wall : wallList) {
            graphics2D.drawImage(wall.image, wall.x,
                    wall.y, gamePanel.tileSize, gamePanel.tileSize, null);
        }

        for (Brick brick : brickList) {
            brick.draw(graphics2D, gamePanel);
        }

    }
}
