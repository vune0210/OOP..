package tile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class FlameTile extends Tile {

    public static BufferedImage Exploded,Exploded1,Exploded2;
    public static BufferedImage eHorizontal,eHorizontal2,eHorizontal1,eVertical,eVertical1,eVertical2;
    public static BufferedImage eHorizontalLeft,eHorizontalLeft2,eHorizontalLeft1;
    public static BufferedImage eHorizontalRight,eHorizontalRight1,eHorizontalRight2;
    public static BufferedImage eVerticalDown,eVerticalDown1,eVerticalDown2;
    public static BufferedImage eVerticalTop,eVerticalTop1,eVerticalTop2;

    public FlameTile(int x, int y) {
        super(x,y);
        this.loadImage();
    }
    public void loadImage() {
        try {
            Exploded = ImageIO.read(new File("src/main/resources/Bomb/bomb_exploded.png"));
            Exploded1 = ImageIO.read(new File("src/main/resources/Bomb/bomb_exploded1.png"));
            Exploded2 = ImageIO.read(new File("src/main/resources/Bomb/bomb_exploded2.png"));
            eHorizontal = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal.png"));
            eHorizontal1 = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal1.png"));
            eHorizontal2 = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal2.png"));
            eVertical = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical.png"));
            eVertical1 = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical1.png"));
            eVertical2 = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical2.png"));
            eHorizontalLeft = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal_left_last.png"));
            eHorizontalLeft1 = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal_left_last1.png"));
            eHorizontalLeft2 = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal_left_last2.png"));
            eHorizontalRight = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal_right_last.png"));
            eHorizontalRight1 = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal_right_last1.png"));
            eHorizontalRight2 = ImageIO.read(new File("src/main/resources/Bomb/explosion_horizontal_right_last2.png"));
            eVerticalDown = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical_down_last.png"));
            eVerticalDown1 = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical_down_last1.png"));
            eVerticalDown2 = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical_down_last2.png"));
            eVerticalTop = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical_top_last.png"));
            eVerticalTop1 = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical_top_last1.png"));
            eVerticalTop2 = ImageIO.read(new File("src/main/resources/Bomb/explosion_vertical_top_last2.png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
