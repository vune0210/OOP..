package tile;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Grass extends Tile {
    public Grass(int x, int y) throws IOException {
        super(x, y);
        this.loadImage();
    }

    @Override
    public void loadImage() {
        try {
            this.image = ImageIO.read(new File("src/main/resources/Tiles/grass.png"));
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

}
