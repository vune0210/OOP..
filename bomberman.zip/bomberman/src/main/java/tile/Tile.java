package tile;

import java.awt.image.BufferedImage;
import java.io.IOException;

public abstract class Tile {

    public BufferedImage image;
    public int x;
    public int y;
    public Tile(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract void loadImage() throws IOException;

}
