package tile;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Wall extends Tile {
    public Wall(int x, int y) {
        super(x, y);
        this.loadImage();
    }

    @Override
    public void loadImage() {
        try {
            this.image = ImageIO.read(new File("src/main/resources/Tiles/wall.png"));
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
