package tile;

import entity.Bomb;
import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

public class Brick extends Tile {

    int tileX, tileY;
    BufferedImage brick, brick_exploded, brick_exploded1, brick_exploded2;
    public int spriteNum = 1;
    public int spriteCount = 0;

    public Brick(int x, int y, int tileX, int tileY) {
        super(x, y);
        this.loadImage();
        this.image = brick;
    }

    @Override
    public void loadImage() {
        try {
            brick = ImageIO.read(new File("src/main/resources/Tiles/brick.png"));
            brick_exploded = ImageIO.read(new File("src/main/resources/Tiles/brick_exploded.png"));
            brick_exploded1 = ImageIO.read(new File("src/main/resources/Tiles/brick_exploded1.png"));
            brick_exploded2 = ImageIO.read(new File("src/main/resources/Tiles/brick_exploded2.png"));
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    public void update(GamePanel gamePanel, List<Brick> brickList, Bomb bomb, int tileMap[][]) {

        if (bomb.status.equals("exploding")) {
            if (checkCollisionFlame(brickList, bomb)) {
                spriteCount++;
                if (spriteCount > 25 && spriteCount <= 27) if (spriteNum == 1) spriteNum = 2;
                if (spriteCount > 27 && spriteCount <= 29) if (spriteNum == 2) spriteNum = 3;
                if (spriteCount > 29) if (spriteNum == 3) {
                    spriteNum = 4;
                    spriteCount = 0;
                }
                if (spriteNum == 1) image = brick_exploded;
                if (spriteNum == 2) image = brick_exploded1;
                if (spriteNum == 3) image = brick_exploded2;
                if (spriteCount >= 29) {
                    image= null;
                    tileMap[tileY][tileX] = 0;
                    for(int i = 0; i < brickList.size(); i++) {
                        if (brickList.get(i).tileX == tileX && brickList.get(i).tileY == tileY) {
                            brickList.set(i, new Brick(0, 0, 0, 0));
                            break;
                        }
                    }
                }
            }

        }
    }

    boolean checkCollisionFlame(List<Brick> brickList, Bomb bomb) {

        return true;
    }

    public void draw(Graphics2D graphics2D, GamePanel gamePanel) {
        graphics2D.drawImage(image, x, y, gamePanel.tileSize, gamePanel.tileSize, null);
    }
}
