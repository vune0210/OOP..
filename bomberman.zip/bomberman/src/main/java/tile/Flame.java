package tile;

import entity.Bomb;
import main.GamePanel;
import main.KeyHendler;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class Flame {
    public List<FlameTile> flameList = new ArrayList<FlameTile>();
    public GamePanel gp;
    public int spriteNum = 1;
    public int spriteCount = 0;
    public String direction;
    public Flame (int x, int y, int tile, int range, GamePanel gp) {
        this.gp = gp;
        if (tile == 0) direction = "up";
        if (tile == 1) direction = "down";
        if (tile == 2) direction = "left";
        if (tile == 3) direction = "right";
        flameList.add(new FlameTile(x,y));
        switch (direction) {
            case "up":
                for (int i = 0; i < range; i++) {
                    y -= gp.tileSize;
                    flameList.add(new FlameTile(x, y));
                }
                break;
            case "down":
                for (int i = 0; i < range; i++) {
                    y += gp.tileSize;
                    flameList.add(new FlameTile(x, y));
                }
                break;
            case "right":
                for (int i = 0; i < range; i++) {
                    x += gp.tileSize;
                    flameList.add(new FlameTile(x, y));
                }
                break;
            case "left":
                for (int i = 0; i < range; i++) {
                    x -= gp.tileSize;
                    flameList.add(new FlameTile(x, y));
                }
                break;
        }
    }

    public void updateFlame(TileManager tileM, Bomb b) {
        spriteCount++;
        if (spriteCount > 25 && spriteCount <= 27) if (spriteNum == 1) spriteNum = 2;
        if (spriteCount > 27 && spriteCount <=29) if (spriteNum == 2) spriteNum = 3;
        if (spriteCount > 29) if (spriteNum == 3) {
            spriteNum = 4;
            flameList.removeAll(flameList);
            spriteCount = 0;
        }
    }

    public void draw(Graphics2D g2) {
        BufferedImage image = null;
        BufferedImage imageLast = null;
        BufferedImage imageCenter = null;
        if (spriteNum == 1) imageCenter = FlameTile.Exploded2;
        if (spriteNum == 2) imageCenter = FlameTile.Exploded1;
        if (spriteNum == 3) imageCenter = FlameTile.Exploded;
        if (spriteNum == 4) imageCenter = null;
        switch (direction) {
            case "up":
                if (spriteNum == 1) imageLast = FlameTile.eVerticalTop2;
                if (spriteNum == 2) imageLast = FlameTile.eVerticalTop1;
                if (spriteNum == 3) imageLast = FlameTile.eVerticalTop;
                if (spriteNum == 4) imageLast = null;
                break;
            case "down":
                if (spriteNum == 1) imageLast = FlameTile.eVerticalDown2;
                if (spriteNum == 2) imageLast = FlameTile.eVerticalDown1;
                if (spriteNum == 3) imageLast = FlameTile.eVerticalDown;
                if (spriteNum == 4) imageLast = null;
                break;
            case "left":
                if (spriteNum == 1) imageLast = FlameTile.eHorizontalLeft2;
                if (spriteNum == 2) imageLast = FlameTile.eHorizontalLeft1;
                if (spriteNum == 3) imageLast = FlameTile.eHorizontalLeft;
                if (spriteNum == 4) imageLast = null;
                break;
            case "right":
                if (spriteNum == 1) imageLast = FlameTile.eHorizontalRight2;
                if (spriteNum == 2) imageLast = FlameTile.eHorizontalRight1;
                if (spriteNum == 3) imageLast = FlameTile.eHorizontalRight;
                if (spriteNum == 4) imageLast = null;
                break;
        }
        switch (direction) {
            case "up":
            case "down":
                if (spriteNum == 1) image = FlameTile.eVertical2;
                if (spriteNum == 2) image = FlameTile.eVertical1;
                if (spriteNum == 3) image = FlameTile.eVertical;
                if (spriteNum == 4) image = null;
                break;
            case "left":
            case "right":
                if (spriteNum == 1) image = FlameTile.eHorizontal2;
                if (spriteNum == 2) image = FlameTile.eHorizontal1;
                if (spriteNum == 3) image = FlameTile.eHorizontal;
                if (spriteNum == 4) image = null;
                break;
        }
        if (flameList.size() == 1) g2.drawImage(imageCenter, flameList.get(0).x,
                flameList.get(0).y, gp.tileSize, gp.tileSize, null );
        else {
            g2.drawImage(imageCenter, flameList.get(0).x, flameList.get(0).y, gp.tileSize, gp.tileSize, null);
            for (int i = 1; i < flameList.size() - 1; i++) {
                g2.drawImage(image, flameList.get(i).x, flameList.get(i).y, gp.tileSize, gp.tileSize, null);
            }
            g2.drawImage(imageLast, flameList.get(flameList.size() - 1).x,
                    flameList.get(flameList.size() - 1).y, gp.tileSize, gp.tileSize, null);
        }
        if (spriteNum == 4) flameList.removeAll(flameList);
    }
}
